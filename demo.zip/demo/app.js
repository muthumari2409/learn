function addTask() {
    let input = document.getElementById("taskInput");
    let taskText = input.value.trim();

    if (taskText === "") {
        alert("Please enter a task!");
        return;
    }

    let ul = document.getElementById("taskList");

    let li = document.createElement("li");
    li.innerHTML = `
        <span class="task-text">${taskText}</span>

        <span>
            <span class="edit-btn" onclick="editTask(this)">✎</span>
            <span class="delete-btn" onclick="deleteTask(this)">✖</span>
        </span>
    `;

    ul.appendChild(li);
    input.value = "";
}

// UPDATE (EDIT)
function editTask(editBtn) {
    let li = editBtn.parentElement.parentElement;
    let currentTask = li.querySelector(".task-text").textContent;

    let newTask = prompt("Edit your task:", currentTask);

    if (newTask !== null && newTask.trim() !== "") {
        li.querySelector(".task-text").textContent = newTask.trim();
    }
}

// DELETE
function deleteTask(task) {
    task.parentElement.parentElement.remove();
}
